public class Main {
    public static void main(String[] args) {

        int[] arr = {4, 20, 13, 5, 10};
        MaxHeap maxHeap = new MaxHeap(arr);

        maxHeap.heapify(0);

        maxHeap.printHeap();
    }
}