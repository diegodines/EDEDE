public class Main {
    public static void main(String[] args) {
        //Insertar nodos
        Arbol arbol = new Arbol(30);
        Nodo nodo2 = new Nodo(12);
        Nodo nodo3 = new Nodo(35);
        Nodo nodo4 = new Nodo(43);
        Nodo nodo5 = new Nodo(55);

        arbol.raiz.hijos.add(nodo2);
        arbol.raiz.hijos.add(nodo3);
        nodo2.hijos.add(nodo4);
        nodo2.hijos.add(nodo5);

        
        System.out.println("El árbol tiene " + arbol.contarNodos() + " nodos.");
    }
}