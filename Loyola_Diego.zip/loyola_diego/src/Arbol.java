class Arbol {
    Nodo raiz;

    public Arbol(int valorRaiz) {
        raiz = new Nodo(valorRaiz);
    }

    public int contarNodos() {
        return contarNodos(raiz);
    }

    private int contarNodos(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        int contador = 1;

        for (Nodo hijo : nodo.hijos) {
            contador += contarNodos(hijo);
        }

        return contador;
    }
}
