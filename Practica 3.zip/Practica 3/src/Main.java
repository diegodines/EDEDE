import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Main {
    private Nodo cabeza;

    public Main() {
        cabeza = null;
    }


    public void agregarNodo(int id, int dato) {
        Nodo nuevoNodo = new Nodo(id, dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevoNodo);
        }
    }


    public void ordenarLista() {
        ArrayList<Nodo> nodos = new ArrayList<>();
        Nodo actual = cabeza;

        while (actual != null) {
            nodos.add(actual);
            actual = actual.getSiguiente();
        }

        Collections.sort(nodos, (nodo1, nodo2) -> Integer.compare(nodo1.getDato(), nodo2.getDato()));

        cabeza = nodos.get(0);
        actual = cabeza;

        for (int i = 1; i < nodos.size(); i++) {
            actual.setSiguiente(nodos.get(i));
            actual = actual.getSiguiente();
        }
        actual.setSiguiente(null);
    }


    public void mostrarLista() {
        Nodo actual = cabeza;

        System.out.print("Lista Original: ");
        while (actual != null) {
            System.out.print("(ID: " + actual.getId() + " Dato: " + actual.getDato() + ") ");
            actual = actual.getSiguiente();
        }

        System.out.println();

        ordenarLista();
        actual = cabeza;

        System.out.print("Lista Ordenada: ");
        while (actual != null) {
            System.out.print("(ID: " + actual.getId() + " Dato: " + actual.getDato() + ") ");
            actual = actual.getSiguiente();
        }
    }



    public static void main(String[] args) {
        Main lista = new Main();
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            int numRandom = random.nextInt(100);
            lista.agregarNodo(i, numRandom);
        }
        lista.mostrarLista();
    }
}