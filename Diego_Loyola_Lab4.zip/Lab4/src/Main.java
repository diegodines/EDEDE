import java.util.*;

class Nodo {
    int valor;
    Nodo siguiente;

    public Nodo(int valor) {
        this.valor = valor;
    }
}

class ListaEnlazada {
    Nodo cabeza;

    public void agregarNodo(int valor) {
        Nodo nuevoNodo = new Nodo(valor);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
    }

    public double calcularPromedio() {
        Nodo actual = cabeza;
        int suma = 0;
        int contador = 0;

        while (actual != null) {
            suma += actual.valor;
            contador++;
            actual = actual.siguiente;
        }

        return (double) suma /contador;
    }

    public ListaEnlazada crearNuevaListaMayorQuePromedio(double promedio) {
        ListaEnlazada nuevaLista = new ListaEnlazada();
        Nodo actual = cabeza;

        while (actual != null) {
            if (actual.valor > promedio) {
                nuevaLista.agregarNodo(actual.valor);
            }
            actual = actual.siguiente;
        }

        return nuevaLista;
    }

    public void ordenar() {
        List<Integer> valores = new ArrayList<>();
        Nodo actual = cabeza;

        while (actual != null) {
            valores.add(actual.valor);
            actual = actual.siguiente;
        }

        Collections.sort(valores);

        actual = cabeza;
        for (int valor : valores) {
            actual.valor = valor;
            actual = actual.siguiente;
        }
    }

    public void imprimir() {
        Nodo actual = cabeza;

        while (actual != null) {
            System.out.print(actual.valor + " ");
            actual = actual.siguiente;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {

        ListaEnlazada lista1 = new ListaEnlazada();
        ListaEnlazada lista2 = new ListaEnlazada();

        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int valor1 = random.nextInt(100);
            int valor2 = random.nextInt(100);
            lista1.agregarNodo(valor1);
            lista2.agregarNodo(valor2);
        }

        System.out.println("Lista 1:");
        lista1.imprimir();

        double promedioLista1 = lista1.calcularPromedio();
        System.out.println("Promedio de lista 1: " + promedioLista1);

        System.out.println("\nLista 2:");
        lista2.imprimir();

        double promedioLista2 = lista2.calcularPromedio();
        System.out.println("Promedio de lista 2: " + promedioLista2);

        ListaEnlazada nuevaLista1 = lista1.crearNuevaListaMayorQuePromedio(promedioLista1);

        ListaEnlazada nuevaLista2 = lista2.crearNuevaListaMayorQuePromedio(promedioLista2);

        ListaEnlazada nuevaListaCombinada = nuevaLista1;
        nuevaListaCombinada.cabeza = unirListasOrdenadas(nuevaListaCombinada.cabeza, nuevaLista2.cabeza);
        nuevaListaCombinada.ordenar();

        System.out.println("\nNueva lista combinada y ordenada:");
        nuevaListaCombinada.imprimir();
    }

    public static Nodo unirListasOrdenadas(Nodo cabeza1, Nodo cabeza2) {
        if (cabeza1 == null) {
            return cabeza2;
        }
        if (cabeza2 == null) {
            return cabeza1;
        }

        Nodo cabezaNueva;
        if (cabeza1.valor < cabeza2.valor) {
            cabezaNueva = cabeza1;
            cabezaNueva.siguiente = unirListasOrdenadas(cabeza1.siguiente, cabeza2);
        } else {
            cabezaNueva = cabeza2;
            cabezaNueva.siguiente = unirListasOrdenadas(cabeza1, cabeza2.siguiente);
        }

        return cabezaNueva;
    }
}