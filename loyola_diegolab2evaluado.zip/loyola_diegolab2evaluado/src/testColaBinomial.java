class testColaBinomial{
    public static void main(String[] args)
    {
        ColaBinomial b = new ColaBinomial();
        //Inserta valores
        b.Insert(2);
        b.Insert(17);
        b.Insert(12);
        b.Insert(4);
        b.Insert(7);
        b.Insert(1);
        b.Insert(10);
        b.Insert(18);
        b.Insert(21);
        b.Insert(6);
        b.Insert(15);


        System.out.println("tamaño cola binomial = " + b.cont());







        b.print();
        System.out.println("el costo del metodo es O(n) debido a que realiza operaciones simples que dependen del numero de nodos y n representa el numero de nodos de la lista ");
    }
}