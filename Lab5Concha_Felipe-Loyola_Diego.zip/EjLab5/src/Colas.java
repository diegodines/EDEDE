import java.util.LinkedList;
import java.util.Queue;

public class Colas {
    class RecentCounter {
        private Queue<Integer> solicitudes;

        public RecentCounter() {
            solicitudes = new LinkedList<>();
        }

        public int ping(int t) {
            solicitudes.offer(t);

            while (solicitudes.peek() < t - 3000) {
                solicitudes.poll();
            }

            return solicitudes.size();
        }
    }

    // DA ERROR, PERO EN LETCODE PEDIA TENER EL STATIC
    public class Main {
        public static void main(String[] args) {

            RecentCounter contadorReciente = new RecentCounter();

            System.out.println(contadorReciente.ping(1));
            System.out.println(contadorReciente.ping(100));
            System.out.println(contadorReciente.ping(3001));
            System.out.println(contadorReciente.ping(3002));
        }
    }
}
//933. Number of Recent Calls
//https://leetcode.com/problems/number-of-recent-calls/submissions/
