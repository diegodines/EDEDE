import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

//DIEGO LOYOLA
class Nodo {
    String palabra;
    List<Pagina> paginas;
    int height;
    Nodo left, right;

    Nodo(String palabra, int pag) {
        this.palabra = palabra;
        this.paginas = new ArrayList<>();
        this.paginas.add(new Pagina(pag, 1));
        this.height = 1;
    }
}
class Pagina {
    int numero;
    int contador;

    Pagina(int numero, int contador) {
        this.numero = numero;
        this.contador = contador;
    }
}

class ArbolAVL {
    Nodo root;

    int height(Nodo N) {
        if (N == null)
            return 0;
        return N.height;
    }

    int max(int a, int b) {
        return Math.max(a, b);
    }

    Nodo rotacionDer(Nodo nodo) {
        Nodo izq = nodo.left;
        Nodo der = izq.right;
        izq.right = nodo;
        nodo.left = der;
        nodo.height = max(height(nodo.left), height(nodo.right)) + 1;
        izq.height = max(height(izq.left), height(izq.right)) + 1;
        return izq;
    }

    Nodo rotacionIzq(Nodo nodo) {
        Nodo der = nodo.right;
        Nodo izq = der.left;
        der.left = nodo;
        nodo.right = izq;
        nodo.height = max(height(nodo.left), height(nodo.right)) + 1;
        der.height = max(height(der.left), height(der.right)) + 1;
        return der;
    }

    int obtieneBalance(Nodo nodo) {
        if (nodo == null)
            return 0;
        return height(nodo.left) - height(nodo.right);
    }

    Nodo insert(Nodo nodo, String palabra, int pag) {
        if (nodo == null)
            return (new Nodo(palabra,pag));

        int compara = palabra.compareTo(nodo.palabra);

        if (compara < 0)
            nodo.left = insert(nodo.left, palabra, pag);
        else if (compara > 0)
            nodo.right = insert(nodo.right, palabra, pag);
        else {
            boolean encontrado = false;
            for (Pagina p : nodo.paginas) {
                if (p.numero == pag) {
                    p.contador++;
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                nodo.paginas.add(new Pagina(pag, 1));
            }
            return nodo;
        }

        nodo.height = 1 + max(height(nodo.left), height(nodo.right));

        int balance = obtieneBalance(nodo);

        if (balance > 1 && palabra.compareTo(nodo.left.palabra) < 0)
            return rotacionDer(nodo);

        if (balance < -1 && palabra.compareTo(nodo.right.palabra) > 0)
            return rotacionIzq(nodo);

        if (balance > 1 && palabra.compareTo(nodo.left.palabra) > 0) {
            nodo.left = rotacionIzq(nodo.left);
            return rotacionDer(nodo);
        }

        if (balance < -1 && palabra.compareTo(nodo.right.palabra) < 0) {
            nodo.right = rotacionDer(nodo.right);
            return rotacionIzq(nodo);
        }

        return nodo;
    }
    void preOrder(Nodo nodo) {
        if (nodo != null) {
            System.out.print(nodo.palabra + " ");
            preOrder(nodo.left);
            preOrder(nodo.right);
        }
    }


    Nodo search(Nodo nodo, String palabra) {
        if (nodo == null || nodo.palabra.equals(palabra))
            return nodo;

        if (nodo.palabra.compareTo(palabra) > 0)
            return search(nodo.left, palabra);

        return search(nodo.right, palabra);
    }
}
class Indice {
    ArbolAVL arbol;

    Indice() {
        this.arbol = new ArbolAVL();
    }

    void addPalabra(String palabra, int pag) {
        this.arbol.root = this.arbol.insert(this.arbol.root, palabra, pag);
    }

    Nodo searchPalabra(String word) {
        return this.arbol.search(this.arbol.root, word);
    }
}

public class Main{
    public static void main(String[] args) {
        Indice indice = new Indice();
        String archivo = "archivo.txt";
        int pagina = 1;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] segmentosAIngresar = linea.split("\\\\");
                for (int i = 1; i < segmentosAIngresar.length; i += 2) {
                    String word = segmentosAIngresar[i];
                    indice.addPalabra(word.toLowerCase(), pagina);
                }
                if (linea.contains("|")) {
                    pagina++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        printIndice(indice.arbol.root);

        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("Ingresa una palabra o frase a buscar: ");
            String palabraBuscada = scanner.nextLine();

            Nodo nodoEncontrado = indice.searchPalabra(palabraBuscada);
            if (nodoEncontrado != null) {
                System.out.println("Palabra: " + nodoEncontrado.palabra);
                System.out.println("Apariciones en las páginas:");
                for (Pagina p : nodoEncontrado.paginas) {
                    System.out.println("- Página " + p.numero + ": " + p.contador + " veces");
                }
            } else {
                System.out.println("La palabra no fue encontrada en el índice.");
            }
        }
    }
    static void printIndice(Nodo nodo) {
        if (nodo != null) {
            printIndice(nodo.left);

            StringBuilder sb = new StringBuilder();
            sb.append(nodo.palabra).append(" ");

            for (Pagina p : nodo.paginas) {
                sb.append(p.numero).append("(").append(p.contador).append("), ");
            }
            System.out.println(sb.toString());
            printIndice(nodo.right);
        }
    }
}