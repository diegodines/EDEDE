public class Ejercicio1 {
    class Solution {
        public String removeOuterParentheses(String s) {
            StringBuilder resultado = new StringBuilder();
            int contadorAbiertos = 0;

            for (char c : s.toCharArray()) {
                if (c == '(') {
                    if (contadorAbiertos > 0) {
                        resultado.append(c);
                    }
                    contadorAbiertos++;
                } else if (c == ')') {
                    contadorAbiertos--;
                    if (contadorAbiertos > 0) {
                        resultado.append(c);
                    }
                }
            }
            return resultado.toString();
        }
    }
}

//https://leetcode.com/problems/remove-outermost-parentheses/submissions/