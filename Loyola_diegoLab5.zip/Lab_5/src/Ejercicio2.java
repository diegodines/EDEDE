import java.util.LinkedList;
import java.util.Queue;

public class Ejercicio2 {
    class RecentCounter {
        private Queue<Integer> solicitudes;

        public RecentCounter() {
            solicitudes = new LinkedList<>();
        }

        public int ping(int t) {
            solicitudes.offer(t);

            while (solicitudes.peek() < t - 3000) {
                solicitudes.poll();
            }
            return solicitudes.size();
        }
    }

    public class Main {
        public static void main(String[] args) {
            RecentCounter contadorReciente = new RecentCounter();
            System.out.println(contadorReciente.ping(1));     // Devuelve 1
            System.out.println(contadorReciente.ping(100));   // Devuelve 2
            System.out.println(contadorReciente.ping(3001));  // Devuelve 3
            System.out.println(contadorReciente.ping(3002));  // Devuelve 3
        }
    }

/**
 * Your RecentCounter object will be instantiated and called as such:
 * RecentCounter obj = new RecentCounter();
 * int param_1 = obj.ping(t);
 */
}

//https://leetcode.com/problems/number-of-recent-calls/submissions/